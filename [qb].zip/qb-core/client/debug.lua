QBCore.Debug = function(resource, obj, depth)
	TriggerServerEvent('QBCore:DebugSomething', resource, obj, depth)
end