module.exports = {
    publicPath: './',
    productionSourceMap: false,
    filenameHashing: false,
    outputDir: "../ui",

}