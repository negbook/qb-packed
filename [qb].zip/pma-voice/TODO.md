## TODO
- [ ] Implement a easy way to get the players current radio channel
		- probably re-implement the GlobalState with another radio table leading to the players current radio channel, as you can only redefine - tables, can't define variables in it.
- [ ] Use commands to define voiceModes in shared.lua and only leave debug logs in shared.lua
- [ ] Convert the UI to React.
- [ ] Multiple radio channels
