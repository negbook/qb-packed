# qb-logs
Discord Logging System For QB-Core
